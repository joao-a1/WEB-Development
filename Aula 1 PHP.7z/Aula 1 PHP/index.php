<!doctype html>
<html>
    <head>
    </head>
    <body>

    <h1>
    <?php
        $nome = "João"; #string
        $nota = 8.5; #ponto flutuante
        $idade = 20; #inteiro
        $cores = ["verde", "vermelho"]; #vetor
        $estados = ["RS" => "perto", "MG" => "longe"];

        echo "teste";
        print("teste");
        // Este é um comentário estilo C
        # Este é um comentário estilo SHELL

        /*
        Este é um comentário estilo SQL
        */

        echo "Oi, meu nome é " . $nome;
        print("idade: $idade");
        echo "nota: " . $nota;
        echo "<br>";
        $cores[] = "azul";
        var_dump($cores);
        print("<br>");
        var_dump($estados);

        print("<hr>");

        $cores = "Teste";
        var_dump($cores);
        print("<br>");
        $estados["SC"] = "Aqui mesmo";
        print_r($estados);
        
        $variavel = [1, 2, array("a", "2", "c")];
        var_dump($variavel);

        #verificar SELECT

        if ($idade >= 18) {
            echo "Maior de idade";
        } else {
            echo "Menor de idade";
        }

        $i = 12;

        print("<hr>");

        while ($i <= 10) {
            print($i);
        }

        print("<hr>");

        do {
            print($i);
        } while ($i <= 10);

        print("<hr>");

        for ($i = 0;$i < 10;$i++) {
            print($i);
        }

        print("<hr>");

        foreach ($estados as $k => $e) {
            print("Estado: $k: $e<br>")  ;          
        }
        
        /*
        foreach ($cores as $c) {
            print("Cor: $c <br>");           
        }
        */

        print("<hr>");

        function quadrado($numero) {
            return $numero **2;
        }

        print(quadrado(3)."<br>");
        echo quadrado(5)."<br>";
        echo quadrado(8)."<br>";

    ?>
    </h1>
    </body>
</html>