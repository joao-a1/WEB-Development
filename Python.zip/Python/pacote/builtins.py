print("Esse é um exemplo")

print(type("Teste"))
print(dir())

nome = "joao"
idade = 15
nome = nome.replace("joao", "lucas")
print(nome)
__builtins__.print(nome)

print(type("ola"))
print(type(1))
print(type(1.5))
print(type(True))
print(type([10, 5, 6, 7]))
print(type((10, 5, 6, 7)))

teste = {}
print(type(teste))

print(1 + int('2'))
print(1 + float('1.5'))
print(str(1) + '2')
