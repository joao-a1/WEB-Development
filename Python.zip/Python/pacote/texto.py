texto = "Esse é um teste"

print(texto[0])
print(texto[7])

print(texto[8])
print(texto[5:8])

frase = "Internacional, maior clube do RS."
print(frase)
frase = "Internacional, maior \n clube do RS."
print(frase)

frase = """
    Não
    tem
    copinha
    nem
    mundial
"""
print(frase)
frase = frase.upper()
print(frase)

fruits = ['apple', 'banana', 'cherry']

x = fruits.count("cherry")
print(x)



"""
Faça um programa que leia o valor em reais da
Venda do Yuri Alberto e calcule o valor
equivalente em dólares.
O usuário deve informar, além do valor em reais, o valor da cotação do dólar.
"""


cotacao = float(input("Informe a cotação do dólar:"))
reais = float(input("Informe o valor em reais para conversão:"))

total = reais/cotacao
print("Você possui ", total, " em dólares.")
