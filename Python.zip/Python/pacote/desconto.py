'''
Faça um código em Python para dar 20% de desconto para pessoas
com mais de 50 anos ou quando o total de compra for maior que
200 reais.
'''

nome = str(input("Digite seu nome:"))
idade = int(input("Digite sua idade"))
compra = 0
deci = "Sim"

while deci == "Sim":
    resp = str(input("Vai comprar?"))
    if resp == "Sim" or resp == "sim":
        compra += 50
    else:
        deci = "Não"


if idade > 50 or compra > 200:
    desc = compra * 0.2
    compra -= desc

'''
if condicao:
    #tem desconto
else:
    #não tem desconto
'''

print("Total de Compras: ", compra)

# trabalhando com if

condicao = idade > 18

if condicao:
    print("Maior de Idade")
else:
    print("Menor de Idade")
