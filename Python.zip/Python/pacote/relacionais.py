# igual
print(10 == 20)

# diferente
print(10 != 20)

# comparativo
print(10 > 9)

# lógicos
print(True or False)
print(False or False)
print(False and True)
print(False and False)