resultado = (2+2)*2
print(resultado)