'''
Soma
Subtração
Multiplicação
Divisão
Exponenciação
Módulo
'''

numero1 = int(input("Digite um número:"))
numero2 = int(input("Digite um número:"))

resultadosSoma = numero1+numero2
print(resultadosSoma)

resultadoMulti = numero1*numero2
print(resultadoMulti)

resultadoDiv = numero1 / numero2
print(resultadoDiv)

resultadoExpo = numero1 ** numero2
print(resultadoExpo)

resultadoMod = numero1 % numero2
print("Resultado {}".format(resultadoMod))
print("Resultado" , resultadoMod)
print(f"Resultado {resultadoMod}")

nome = "João"
media = (numero1 + numero2) / 2
print('{0} media igual a {1:4.2f}'.format(nome, media))
print(f"Resultado da Multiplicação {resultadoMulti} e resultado da Divisão {resultadoDiv}")