#teste

print("teste")

'''
Tipos de dados
'''

print(True)
print(False)

print(1.5+3.5)
print(1+3)

print("Olá")

print(["Fabrício", "Lucas", "Carlos", "Renan"])

idade = 30
print(idade)

idade = "Trinta anos"
print(idade)

idade = int(2)
# = str(...)
# = float(...)
print(idade)


# Façam um código em Python para calcular o IMC

altura = float(input("Digite a sua altura:"))
peso = int(input("Digite o seu peso:"))

imc = peso / (altura * altura)

print(imc)