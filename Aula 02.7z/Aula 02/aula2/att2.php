<!DOCTYPE html>
<html>
<head>
    <meta charset = "UTF-8">
    <title>Aula 2</title>
    <style>
        .header {
            background-color: blue;
        };

        #header {
            background-color: green;
        };

        header {
            background-color: red;
            font-family: 'Courier New',
            Courier, monospace;
            font-weight: bold;

            margin: 10px;
        };
    </style>
</head>
<body>

    <h1 style="color: #000000; font-family: Tahoma"> 
        Teste
    </h1>

        <!-- HTML -->
<?php 
        // # especificidade 
?>

        
       <div>
       <'header'> - Não Confundir com <'head'>
       </div> 
       <div>Div</div>
       <header>Header</header>
       
        
</body>
</html>