<!doctype html>
<html>
    <head>
    </head>
    <body>

    <h1>
    <?php

    print("<hr>");

    function juro(
        $vi, 
        $taxa, 
        $tempo
    ){
        $vf = $vi * (1 + $taxa / 100) ** $tempo;
        return round($vf, 2);
    }

    print(juro(10000, 0.6, 8));

    print("<hr>");

    function somaTaxa(
        $valor_produto
    ){
        $preco_venda = $valor_produto + ($valor_produto * .2);
        return round($preco_venda, 2);
    }

    echo somaTaxa(100);    

    print("<hr>");

    function validaUsuario(
        $usuario,
        $senha
    ){
        if ($usuario == "admin" and $senha == "root") {
            $acesso = "Login realizado com sucesso.";
        } else {
            $acesso = "Login ou senha inválidos.";
        };
        return $acesso;
    }

    echo validaUsuario("admin", "root");

    print("<hr>");

?>
    </h1>
    </body>
</html>