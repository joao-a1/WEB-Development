<!DOCTYPE html>
<html>
        <title> 
            Atividade 1
        </title>
    <head>
    </head>
    <body>
    <h3>
    <?php 

        print "Atividade 1 <hr>";
    ?>
    </h3>
    <?php
        # Atividade 01 - Meses

        $meses = [
                "Janeiro" => "January", 
                "Fevereiro" => "February ",
                "Marco" => "March",
                "Abril" => "April",
                "Maio" => "May",
                "Junho" => "June",
                "Julho" => "July",
                "Agosto" => "August",
                "Setembro" => "September",
                "Outobro" => "October",
                "Novembro" => "November",
                "Dezembro" => "December"
            ];

        $mes = $_GET["mes"];
        http://localhost/att/atividade1.php?mes=Dezembro

        echo "O mês de <b>$mes</b> convertido em inglês é: <b>". $meses["Dezembro"]
        ."</b><br>";


        

        // Atividade 02 - Percorrendo os meses

        print("<hr>");
        foreach ($meses as $m => $v) { 
            print("Mês de $m em inglês: $v <br>");
        }

        /*  
        Atividade 03 - Calculadora de Juros Compostos
        */

        function juro(
            $vi, 
            $taxa, 
            $tempo
        ){
            $vf = $vi * (1 + $taxa) ** $tempo;
            return round($vf, 2);
        }

        $taxas = [0.6/100, 0.5/100, 0.9/100];
        $tempos = [6, 9, 12];
        $valor_inicial = 10000;

        echo "<br>";

        foreach ($taxas as $taxa) {
            foreach ($tempos as $tempo) {
                echo "Considerando taxa = $taxa, tempo = $tempo 
                e valor inicial = $valor_inicial, 
                O valor final será: " . juro($valor_inicial, $taxa, $tempo) . "<br>";
            }
        }

        print("<hr>");
        print("<br>Simulação 01 - R$ 1000,00 inicial <br>
        Taxa: ");
        echo juro(1000, 0.3, 6) . ".<br>";
        print("<br>Simulação 02 - R$ 600,00 inicial <br>
        Taxa: ");
        echo juro(600, 0.5, 9) . ".<br>";
        print("<br>Simulação 03 - R$ 5000,00 inicial <br>
        Taxa: ");
        echo juro(5000, 0.9, 12) . ".<br>";

    ?>
    </body>
</html>