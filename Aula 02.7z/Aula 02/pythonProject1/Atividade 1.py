lista = [
        "Volta o cão arrependido",
        "Com suas orelhas tão fartas",
        "Com seu osso roído",
        "E com o rabo entre as patas",
        " ",
        "Volta o cão arrependido",
        "Com suas orelhas tão fartas",
        "Com seu osso roído",
        "E com o rabo entre as patas",
]

print(lista)