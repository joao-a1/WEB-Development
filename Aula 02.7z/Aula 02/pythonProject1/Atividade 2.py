
for i in range(0,10):
    print("Tabuada do ", i)
    for j in range(1,11):
        print(i, '*', j, " = ", i*j)

