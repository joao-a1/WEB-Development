lista = []

for i in range(0,10):
    lista.append(int(input("Digite o valor inteiro: ")))

maior = lista[1]
menor = lista[1]

for item in lista:
    #print(item)
    if item > maior:
        maior = item
    if item < menor:
        menor = item

print("Maior: ", maior)
print("Menor: ", menor)
