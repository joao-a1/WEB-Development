
lista = [2,12,20,0,1,3,40,7,5,10]

lista.sort()
print(lista)